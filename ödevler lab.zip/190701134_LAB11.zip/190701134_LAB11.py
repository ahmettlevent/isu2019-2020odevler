"""
SORU - 1 Google Colaboratory nedir?
Ucretsiz gpu imkani saglayan , python dilinde program yazabilecegimiz bir bulut servisidir.

SORU - 2 Google Colaboratory ne amacla kullanilir?
Sisteminizin yetmeyecegi programlari ucretsiz gpu imkani ile gelistirme ve olusturma.

SORU - 3 Google Colaboratory kullanicilarina neler saglar?
Teska K80 gpu ,  ucretsiz 15GB bulut depolama , online python editor.

SORU - 4 Google Colaboratory ile Google Drive nasil calisir?
Colaboratory dosyaları Google drive a saklar ve üstünde çaıştığınız dosyaları oradan çeker.

SORU - 5 Google Colaboratory Github gibi kaynaklarla çalışabilirmi?
Tabiki Github Hesabınıza bağlayabilir veyahut desteklenen bir repository den veri çekebilirsiniz

SORU - 6 Google Colaboratory hangi programlama dillerine destek vermektedir?
Python 2 ve Python 3

SORU - 7 Git nedir? Kim tarafından ne amaçla geliştirilmiştir?
2005 yılında Linus Torvalds tarafından geliştirilen bir versiyon kontrol sistemidir.
Kodlarınızı muhafaza etme,versiyonları yönetme ve takım çalışmalarında erişim izinlerini yönetmenizi sağlayan bir yönetici sistemdir.

SORU - 8  Gitlab ve github arasındaki farklar nelerdir?
GitLab daha çok firmalar tarafından kullanılır.
Githubdan Farkli olarak ucretsiz sürümünde kendi sunucularınıza kurarak sadece kurum ici kullanıcıların erişebileceği GitLab servisi hizmeti bulunmaktadır.

SORU - 9 Git komutlarından init, add, commit, pull, push komutlarının ne işe yaradığını açıklayınız.
init = Yeni bir git dizini olustumak icin kullanilir.
idd = Dizine dosya eklemek icin kullanilir
commit = git commit -m ‘msg’ ile dosyalarınıza bir mesaj ekleyerek locak repo'nuza eklemenizi saglar.
pull = Uzak dizinde yapilan tum  degisiklikleri yerel dizine cekmenizi saglar.
push = Yerel dizinde yaptiginiz degisiklikleri uzak dizine yollamanizi(itmenizi) saglar.

SORU - 10 Html nedir ?
Html bir metin isaretleme dilidir.Bir programlama dili degildir cunku html in tek basina bir islevi yoktur,gorevi kaynaklardan gelen bilgiyi tarayiciya aktarmaktir.
"""
