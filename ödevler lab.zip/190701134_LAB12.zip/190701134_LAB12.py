'''
Cevap 1.
Arduino bir G/Ç kartı ve Processing/Wiring dilinin bir uygulamasını içeren geliştirme ortamından oluşan,
bir fiziksel programlama platformudur.

Cevap 2.
Dosya>Tercihler Bolumunden Derleme ve Yükle Kısımlarına tik atıp tamam dedikten sonra programı çalıştırır isek çıktıda
bize hex dosyasının konumunu belirtecektir.

Cevap 3.
pyserial Kutuphanesi python ile arduino sistemin haberlesmesini saglar.

Cevap 4.
Flask Python için bir framwork görevi görür .Web derleyici olarak çalışır.

Cevap 5.
VirtualEnv, projelerinizde gerekli olan paketleri sistemden bağımsız bir şekilde kurup,
kullanmanızı sağlayacak sanal ortam sağlayan bir yapıdır.
Sistemde Karışıklılık yaratmamak amacıyla kullanılır.

Virtualenv sitesinden indirip setup.py komut dosyasıyla
pip yardımıyla ve linux kullanıcıları için repo’dan
Ben pip ve linux repo kurulumlarından bahsedeceğim. Sırasıyla pip ve repo kurulum kodları:
pip install virtualenv
sudo apt-get install python-virtualenv
ilgili komutu terminal yardımıyla çalıştırdığınızda kurulum gerçekleşecektir.
'''